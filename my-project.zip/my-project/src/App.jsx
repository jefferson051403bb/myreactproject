function App() {
  return (
    <div className="App">
      <h1>Taña Jefferson N.</h1>
      <h2>CAMINOS SARAH</h2>
    </div>
  );
}

export default App;
